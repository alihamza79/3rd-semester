// // Ali_Hamza_22i-2535 Assignment#02
#include <iostream>
#include <string>
#include <cfloat>

using namespace std;
// Function Prototypes
int generateUniqueID();
class Task;
void displayTasksAdd(Task *headTasks);

// Linked Lists to Hold Dependenices of Tasks
class ListDependencies
{
public:
    Task *head;
    ListDependencies *next;
    ListDependencies()
    {
        next = NULL;
    }
    ListDependencies(Task *val)
    {
        next = NULL;
        head = val;
    }
};
// Tasks
class Task
{
public:
    int id;
    float duration;
    float startTime;
    float endTime;
    float latEndTime;
    float latStartTime;
    float slac;
    int skill_id;
    ListDependencies *dependencyIDs;
    ListDependencies *nonDependencyIDs;
    int dependencyCount;
    int nonDependCount;
    string name;
    Task *next;
    // Setting Default Value
    Task()
    {
        next = NULL;
        startTime = -99;
        endTime = -99; // Keeping it Min to Find Max
        latEndTime = 99;
        nonDependCount = 0;
        latStartTime = 99; // Keeping It max to Find min
        dependencyIDs = NULL;
        nonDependencyIDs = NULL;
    }
    // Parameetric Constructor
    Task(int id, string name, float duration, int idSkill)
    {
        this->id = id;
        this->name = name;
        this->duration = duration;
        this->skill_id = idSkill;
        nonDependCount = 0;
        startTime = -99;
        endTime = -99;
        latEndTime = 99;
        latStartTime = 99;
        next = NULL;
        dependencyIDs = NULL;
        nonDependencyIDs = NULL;
    }
    // Finding maximum Early End from the Task dependencies and Assign it to the Task
    void calculateStartTime()
    {
        ListDependencies *temp = dependencyIDs;
        float max = temp->head->endTime;
        while (temp)
        {
            if (temp->head->endTime > max)
            {
                max = temp->head->endTime;
            }
            temp = temp->next;
        }
        startTime = max;
        endTime = startTime + duration;
    }
    // Finding minimum Late Start from the Task dependencies and Assign it to the Task
    void calculateEndTimeBack()
    {
        ListDependencies *temp = nonDependencyIDs;
        float min = temp->head->latStartTime;
        while (temp)
        {
            if (temp->head->latStartTime < min)
            {
                min = temp->head->latStartTime;
            }
            temp = temp->next;
        }
        latEndTime = min;
        latStartTime = latEndTime - duration;
    }
    // Pushing in dependencies List
    void push_back_dep(Task *newNode);
    // Pushing in Dependent List
    void push_back_Nondep(Task *newNode);
    void increaseDepCount()
    {
        dependencyCount++;
    }
    // Calculate Total Depndents of the Task
    void calculateNonDepenCount()
    {
        ListDependencies *temp = nonDependencyIDs;
        while (temp)
        {
            nonDependCount++;
            temp = temp->next;
        }
    }
    // Setters
    void setDuration(float duration)
    {
        this->duration = duration;
    }
    void setDependencyCount(int n)
    {
        dependencyCount = n;
    }
    void setSlack(float slc)
    {
        slac = slc;
    }
    void setStartTime(float stime)
    {
        startTime = stime;
    }
    void setEndTime(float etime)
    {
        endTime = etime;
    }
    void setLatStartTime(float stime)
    {
        latStartTime = stime;
    }
    void setLatEndTime(float etime)
    {
        latEndTime = etime;
    }
    // Printing Dependencies and Dependents
    void printDependencyList()
    {
        cout << "Task ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Duration : " << duration << endl;
        cout << "Dependencies: ";
        if (dependencyIDs == NULL)
        {
            cout << "None" << endl;
        }
        else
        {
            ListDependencies *temp = dependencyIDs;
            while (temp)
            {
                cout << temp->head->name << " ";
                temp = temp->next;
            }
        }

        cout << endl;
    }
    void printNonDependencyList()
    {
        cout << "Task ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Dependencies: ";
        ListDependencies *temp = nonDependencyIDs;
        if (nonDependencyIDs == NULL)
        {
            cout << "None" << endl;
        }
        else
        {
            ListDependencies *temp = nonDependencyIDs;
            while (temp)
            {
                cout << temp->head->name << " ";
                temp = temp->next;
            }
        }

        cout << endl;
    }
    void displayTask()
    {
        cout << "\t" << id << "\t\t" << name << "\t\t" << duration << "\t" << endl;
    }
};
// Push in List dependencyIDs
void Task::push_back_dep(Task *newNode)
{
    ListDependencies *newDep = new ListDependencies(newNode);
    if (dependencyIDs == NULL)
    {
        dependencyIDs = newDep;
    }
    else
    {
        ListDependencies *temp = dependencyIDs;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = newDep;
    }
}
// Push in List NonDependencyIDs
void Task::push_back_Nondep(Task *newNode)
{
    ListDependencies *newDep = new ListDependencies(newNode);
    if (nonDependencyIDs == NULL)
    {
        nonDependencyIDs = newDep;
    }
    else
    {
        ListDependencies *temp = nonDependencyIDs;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = newDep;
    }
}
void setDependencyID(int id, Task *head, Task *temp1)
{
    Task *temp = head;
    while (temp)
    {
        if (temp->id == id)
        {
            temp1->push_back_dep(temp);
            return;
        }
        temp = temp->next;
    }
}
void setNondependencies(int id, Task *head, Task *temp1)
{
    Task *temp = head;
    while (temp)
    {
        if (temp->id == id)
        {
            temp->push_back_Nondep(temp1);
            return;
        }
        temp = temp->next;
    }
}
class Skill
{
public:
    int id;
    string skillName;
    float proficency;
};

class Resource
{
public:
    int id;
    string nameResouce;
    bool available;
    Skill skill;
    Resource *next;

    Resource()
    {
        next = NULL;
    }
    Resource(int id, string name, bool available, Skill skill)
    {
        this->id = id;
        nameResouce = name;
        this->available = available;
        this->skill.id = skill.id;
        this->skill.proficency = skill.proficency;
        this->skill.skillName = skill.skillName;
        next = NULL;
    }
};
// Getting Resource From user and return a resource pointer storing values
Resource *getResource()
{

    int id = generateUniqueID();
    Skill skill;
    bool available;
    int ava;
    string name;

    cout << endl
         << "Enter the Name of the Resource : ";
    cin >> name;
    cout << endl
         << "Is the Resource Available : \n1-Yes\n2-No\n";
    cin >> ava;
    if (ava == 1)
    {
        available = true;
    }
    else
    {
        available = false;
    }
    cout << endl
         << "Enter the name of Skill in Resource " << name << " :";
    cin >> skill.skillName;
    skill.id = generateUniqueID();
    do
    {
        cout << endl
             << "Enter the proficency level of skill " << skill.skillName << " between 0 to 1 : ";
        cin >> skill.proficency;
    } while (skill.proficency < 0 || skill.proficency > 1);
    Resource *temp = new Resource(id, name, available, skill);
    return temp;
}

// Checking whether given Id exist in Tasks
bool checkId(int id, Task *head)
{
    Task *temp = head;
    while (temp)
    {
        if (temp->id == id)
        {
            return true;
        }
        temp = temp->next;
    }
    return false;
}
// Check whether the is a task with Zero dependecies or Zero start Time in Tasks
bool checkZeroDependency(Task *head, int total)
{
    Task *temp = head;
    for (int i = 0; i < total; i++)
    {
        if (temp->dependencyCount == 0)
        {
            return true;
        }
        temp = temp->next;
    }
    return false;
}
// Getting Dependencies for each tasks
void getDependencies(Task *head, int total)
{
    system("CLS");
    cout << "Atleast One Task Should have 0 dependency and 0 Start time..." << endl;
    cout << endl
         << "Enter the dependencies for Each Task : " << endl;
    Task *temp = head;
    int choose, number, j = 0, id;
    for (int i = 0; temp; i++)
    {

        displayTasksAdd(head);
        if (i == total - 1 && !checkZeroDependency(head, i))
        {
            cout << "You have no Entered a task with 0 dependency and 0 start Time.The start time for the task " << temp->name << " wil be set to 0" << endl;

            temp->setStartTime(0);
            temp->setDependencyCount(0);
        }
        else
        {
            cout << "Does the Task " << temp->name << " have dependency : \n1-Yes\n2-No\n";
            cin >> choose;
            if (choose == 1)
            {
                cout << "How many dependencies does the Task " << temp->name << " have : ";
                cin >> number;
                temp->setDependencyCount(number);

                while (number != 0)
                {
                    cout << "Enter the id of " << j + 1 << " dependency from the above tasks : ";
                    cin >> id;

                    if (checkId(id, head))
                    {
                        // Setting Given task id as dependency of the Task
                        setDependencyID(id, head, temp);
                        // Setting the task  as dependent of the given Task id

                        setNondependencies(id, head, temp);
                        number--;
                        j++;
                    }
                    else
                    {
                        cout << "Wrong Id Task does not exist " << endl;
                    }
                }
                j = 0;
            }
            else
            {
                int stime;
                cout << "Enter the Task Start Time : " << endl;
                cin >> stime;
                temp->setStartTime(stime);
                temp->setDependencyCount(0);
            }
        }

        temp = temp->next;
        system("CLS");
    }
}
void displayTasksAdd(Task *headTasks)
{
    Task *temp2 = headTasks;
    cout << "x-----------------------------------------------------------------x" << endl;
    cout << "\tID\t\tName\t\tDuration\t" << endl;
    while (temp2)
    {
        temp2->displayTask();
        temp2 = temp2->next;
    }
    cout << "x------------------------------------------------------------------x" << endl;
}
class Project
{
public:
    int id;
    float duration;
    Task *headTasks;
    Task *headTasksRes;
    Resource *headResource;
    ListDependencies *tempDependId;
    ListDependencies *toPush;
    Project()
    {
        headResource = NULL;
        headTasks = NULL;
        headTasksRes = NULL;
        tempDependId = NULL;
        toPush = NULL;
    }

    // Adding Resources
    void addResources()
    {
        int number;
        int i = 1;
        cout << endl
             << "How many Resources do You want to Add : ";
        cin >> number;
        while (number != 0)
        {
            cout << endl
                 << "Add " << i << "st Resource : " << endl;
            Resource *newResource = getResource();

            if (headResource == NULL)
            {
                headResource = newResource;
            }
            else
            {
                Resource *temp = headResource;
                while (temp->next != NULL)
                {
                    temp = temp->next;
                }
                temp->next = newResource;
            }
            number--;
            i++;
            newResource = NULL;
            system("CLS");
        }
    }
    int taskCount()
    {
        Task *temp = headTasks;
        int count = 0;
        while (temp)
        {
            temp = temp->next;
            count++;
        }
        return count;
    }
    // checking whether the resource matcing skill id exist
    bool checkResourceExist(int skillID)
    {
        Resource *temp = headResource;
        while (temp)
        {
            if (temp->skill.id == skillID && temp->available == true)
            {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }
    // Getting task from user and returnting as a pinter storing values
    Task *getTask()
    {

        int id = generateUniqueID();
        string name;
        cout << endl
             << "Enter the Task name : ";
        cin >> name;
        float duration;
        cout << endl
             << "Enter the Duration Time : ";
        cin >> duration;
        int idSkill;
        cout << "x-------------------------------------------------------------------------x" << endl;
        cout << "Res ID\tName\tAvailable\tSkill ID\tSkill Name\tProficency" << endl;
        displayResourcesAvailable();
        cout << "x-------------------------------------------------------------------------x" << endl;
        cout << endl
             << "Enter the Id of Skill Required : ";
        cin >> idSkill;
        bool check = checkResourceExist(idSkill);

        while (check == false)
        {
            cout << "Wrong Skill Id..." << endl;
            cout << endl
                 << "Enter the Id of Skill Required Again : ";
            cin >> idSkill;
            check = checkResourceExist(idSkill);
        }

        Task *temp = new Task(id, name, duration, idSkill);
        return temp;
    }
    void addTasks()
    {
        // Getting Task and asking their Dependencies
        int number;
        int i = 1;
        int total;
        cout << endl
             << "How many Tasks do You want to Add : ";
        cin >> number;
        total = number;
        while (number != 0)
        {
            cout << endl
                 << "Add " << i << "st Task : " << endl;
            Task *newTask = getTask();

            if (headTasks == NULL)
            {
                headTasks = newTask;
            }
            else
            {
                Task *temp = headTasks;
                while (temp->next != NULL)
                {
                    temp = temp->next;
                }
                temp->next = newTask;
            }
            number--;
            i++;
            newTask = NULL;
            system("CLS");
        }
        system("CLS");
        cout << endl
             << "Tasks You have entered are : " << endl
             << endl;
        displayTasksAdd(headTasks);
        getDependencies(headTasks, total);
    }
    // Forward Pass
    void forwardPass()
    {

        int i = 0, total = taskCount();
        Task *temp1 = headTasks;
        // Caluculating Dependents of Each Task
        while (temp1)
        {
            temp1->calculateNonDepenCount();
            temp1 = temp1->next;
        }
        // Start here Fowrward Logic
        while (i < total)
        {
            Task *temp = headTasks;
            while (temp)
            {
                if (temp->dependencyCount == 0)
                {
                    temp->setStartTime(0);
                    temp->setEndTime(temp->startTime + temp->duration);
                }
                else
                {
                    // Calculating maximum End time and alocating to the Task accrodingly
                    temp->calculateStartTime();
                }

                temp = temp->next;
            }
            i++;
        }
    }
    // Print tasks with Zero Slac
    void printCriticalTasks()
    {
        Task *temp = headTasks;
        float duration = 0;
        cout << "Critical Tasks are : " << endl;
        while (temp)
        {
            if (temp->slac == 0)
            {
                cout << "Name : " << temp->name << endl;
                cout << "ID : " << temp->id << endl
                     << endl;
                duration += temp->duration;
            }
            temp = temp->next;
        }
        cout << endl;
        cout << "Sum of the durations of Critical Task is : " << duration << endl;
    }
    // Returning max Ent Time
    int getMaxEndTime()
    {
        Task *temp = headTasks;
        float max = temp->endTime;
        while (temp)
        {
            if (temp->endTime > max)
            {
                max = temp->endTime;
            }
            temp = temp->next;
        }

        return max;
    }
    void backwardPass()
    {
        int i = 0, total = taskCount();
        int max = getMaxEndTime();

        while (i < total)
        {

            Task *temp = headTasks;
            while (temp)
            {
                // If task has no dependents or max entime then values are predetermined
                if (temp->endTime == max || temp->nonDependencyIDs == NULL)
                {
                    temp->setLatEndTime(max);
                    temp->setLatStartTime(temp->latEndTime - temp->duration);
                }
                else
                {
                    // Calculating minmum late Start time and alocating to the Task accrodingly
                    temp->calculateEndTimeBack();
                }
                temp = temp->next;
            }

            i++;
        }
    }
    // Displaying Tasks
    void printBasicSchedule()
    {
        cout << "Basic Schedule : " << endl;
        cout << "x----------------------------------------------------------------------------------------------------x" << endl;
        cout << "\tID\t\tName\t\tES\t\tEF\t\tLS\t\tLF\tSlac" << endl;
        Task *temp = headTasks;
        while (temp)
        {
            cout << "\t" << temp->id << "\t\t" << temp->name << "\t\t" << temp->startTime << "\t\t" << temp->endTime << "\t\t" << temp->latStartTime << "\t\t" << temp->latEndTime << "\t\t" << temp->slac << endl;
            temp = temp->next;
        }
        cout << "x----------------------------------------------------------------------------------------------------x" << endl;
        cout << endl
             << "Project Compeletion Time is : " << getMaxEndTime() << endl
             << endl;
        printCriticalTasks();
    }
    // Basic CPM
    void calculateBasicSchedule()
    {
        forwardPass();
        backwardPass();

        Task *temp = headTasks;
        while (temp)
        {
            temp->setSlack(temp->latStartTime - temp->startTime);
            temp = temp->next;
        }
    }
    // Push in list tempDependency
    void push_back_tempDep(Task *newNode)
    {
        ListDependencies *newDep = new ListDependencies(newNode);
        if (tempDependId == NULL)
        {
            tempDependId = newDep;
        }
        else
        {
            ListDependencies *temp = tempDependId;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newDep;
        }
    }
    // Removing and returning next task from list tempDependency
    ListDependencies *remove_tempDep(Task *node)
    {
        if (tempDependId == NULL)
        {
            return NULL;
        }
        else if (tempDependId->head == node)
        {
            tempDependId = tempDependId->next;
            return tempDependId;
        }
        else
        {
            ListDependencies *temp = tempDependId;
            while (temp->next != NULL && temp->next->head != node)
            {
                temp = temp->next;
            }
            if (temp->next != NULL)
            {
                temp->next = temp->next->next;
                return temp->next;
            }
        }
    }
    // Checking If the all tasks have Equal Late start
    bool checkEqualLateStart()
    {
        ListDependencies *temp = toPush;
        float same = temp->head->latStartTime;
        while (temp)
        {
            if (temp->head->latStartTime != same)
            {
                return false;
            }
            temp = temp->next;
        }
        return true;
    }
    // Checking and returing Task with lowest Duration
    Task *checkLowestDuration()
    {
        ListDependencies *temp = toPush;
        float min = temp->head->duration;
        while (temp)
        {
            if (temp->head->duration < min)
            {
                min = temp->head->duration;
            }
            temp = temp->next;
        }
        temp = toPush;
        while (temp)
        {
            if (temp->head->duration == min)
            {
                return temp->head;
            }
            temp = temp->next;
        }
    }
    // Checking and returing Task with lowest slac
    Task *checkLowestSlac()
    {
        ListDependencies *temp = toPush;
        float min = temp->head->slac;
        while (temp)
        {
            if (temp->head->slac < min)
            {
                min = temp->head->slac;
            }
            temp = temp->next;
        }
        temp = toPush;
        bool check;
        while (temp)
        {
            if (temp->head->slac != min)
            {
                check = false;
            }
            temp = temp->next;
        }
        if (check == false)
        {
            temp = toPush;
            while (temp)
            {
                if (temp->head->slac == min)
                {
                    return temp->head;
                }
                temp = temp->next;
            }
        }
        else
        {
            return checkLowestDuration();
        }
    }
    // Assigning the Selected task the rest task as dependencies
    void assignDependencies(Task *task)
    {
        remove_toPush(task);
        ListDependencies *temp = toPush;
        while (temp)
        {
            temp->head->push_back_dep(task);
            temp->head->increaseDepCount();
            temp = temp->next;
        }
    }
    // Checking and returnin task with lowest late start time
    Task *checkLowestLateTime()
    {
        ListDependencies *temp = toPush;
        float min = temp->head->latStartTime;
        while (temp)
        {
            if (temp->head->latStartTime < min)
            {
                min = temp->head->latStartTime;
            }
            temp = temp->next;
        }

        temp = toPush;
        while (temp)
        {
            if (temp->head->latStartTime == min)
            {
                return temp->head;
            }
            temp = temp->next;
        }
    }
    // Assigning resources 1) Selecting A task 2) Making other tasks dependency of this Task
    void assignResource()
    {
        if (checkEqualLateStart())
        {
            Task *pass = checkLowestSlac();
            assignDependencies(pass);
        }
        else
        {
            Task *pass = checkLowestSlac();
            assignDependencies(pass);
        }
    }
    // Removing Task from To push list
    void remove_toPush(Task *newNode)
    {
        if (toPush == NULL)
        {
        }
        else if (toPush->head == newNode)
        {
            toPush = toPush->next;
        }
        else
        {
            ListDependencies *temp = toPush;
            while (temp->next != NULL && temp->next->head != newNode)
            {
                temp = temp->next;
            }
            if (temp->next != NULL)
            {
                temp->next = temp->next->next;
            }
        }
    }
    // Checking tasks from temoDependID and assigning resources to the tasks with same resources untill tempDependID become Null
    void checkSameResources()
    {
        while (tempDependId)
        {
            float same = tempDependId->head->skill_id;
            ListDependencies *temp = tempDependId;
            while (temp)
            {
                if (temp->head->skill_id == same)
                {
                    push_back_toPush(temp->head);
                    temp = remove_tempDep(temp->head);
                }
                else
                    temp = temp->next;
            }
            while (toPush)
            {
                assignResource();
            }
        }
    }
    // Pushing in toPush list
    void push_back_toPush(Task *newNode)
    {
        ListDependencies *newDep = new ListDependencies(newNode);
        if (toPush == NULL)
        {
            toPush = newDep;
        }
        else
        {
            ListDependencies *temp = toPush;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newDep;
        }
    }
    // Getting task and pushing them in tempDependID
    void doForDependets(ListDependencies *nonDepends)
    {
        ListDependencies *temp = nonDepends;
        while (temp)
        {
            push_back_tempDep(temp->head);
            temp = temp->next;
        }
        checkSameResources();
    }
    // Function to calculate CPM with resources
    void cpmResources()
    {
        Task *temp = headTasks;
        // Tasks with Zero dependecy
        while (temp)
        {
            if (temp->dependencyCount == 0)
            {
                push_back_tempDep(temp);
            }
            temp = temp->next;
        }
        checkSameResources();
        temp = headTasks;
        // Tasks with dependents More than 1
        while (temp)
        {
            if (temp->nonDependCount > 1)
            {
                doForDependets(temp->nonDependencyIDs);
            }
            temp = temp->next;
        }
        // Forward pass after changing dependencies
        forwardPass();
    }
    float checkResourceProf(int skillId)
    {
        Resource *temp = headResource;
        while (temp)
        {
            if (temp->skill.id == skillId)
            {
                return temp->skill.proficency;
            }
            temp = temp->next;
        }
    }
    void checkSkillProf()
    {
        Task *temp = headTasks;
        while (temp)
        {
            float prof = checkResourceProf(temp->skill_id);
            temp->setDuration(temp->duration / prof);
            temp = temp->next;
        }
    }
    void cpmResourcesWithProf()
    {
        // Checking the proficency of the skill Task required And changing Duration accordingly
        checkSkillProf();
        // Forward Pass
        forwardPass();
        // Display According to Resources
    }
    int returnResourceID(int id)
    {
        Resource *temp = headResource;
        while (temp)
        {
            if (temp->skill.id == id)
            {
                return temp->id;
            }
            temp = temp->next;
        }
    }
    // Displaying tasks after Resources and proficency
    void displayCPM()
    {
        Task *temp = headTasks;
        cout << "x---------------------------------------------------------------------x" << endl;
        cout << "ID\t\tName\t\tES\t\tEF\t\tRes" << endl;
        while (temp)
        {
            int id = returnResourceID(temp->skill_id);
            cout << temp->id << "\t\t" << temp->name << "\t\t" << temp->startTime << "\t\t" << temp->endTime << "\t\t" << id << endl;
            temp = temp->next;
        }
        cout << "x---------------------------------------------------------------------x" << endl;
        cout << "Time for project Completion : " << getMaxEndTime();
        cout << endl;
    }

    void displayTasks()
    {
        Task *temp = headTasks;
        while (temp)
        {
            cout << "\t" << temp->id << "\t\t" << temp->name << "\t\t" << temp->duration << "\t" << endl;
            temp = temp->next;
        }
    }

    void setTaskDuration(float newDuration)
    {
        Task *temp = headTasks;

        while (temp != NULL)
        {
            temp->duration = newDuration;
            temp = temp->next;
        }
    }
    // Return false if task was not found
    bool set_nth_TaskDuration(int position, float newDuration)
    {
        Task *temp = headTasks;
        int currentPosition = 0;

        while (temp != nullptr)
        {
            if (currentPosition == position)
            {
                temp->duration = newDuration;
                return true;
            }
            temp = temp->next;
            currentPosition++;
        }

        return false;
    }
    // Printing dependencies of the Tasks
    void printTaskDependencyList()
    {
        Task *temp = headTasks;
        system("CLS");
        while (temp)
        {
            temp->printDependencyList();
            cout << endl
                 << endl;
            temp = temp->next;
        }
    }
    // Displaying Resources
    void displayResources()
    {
        Resource *temp = headResource;
        if (temp == NULL)
        {
            cout << "No resources in the project." << endl;
            return;
        }
        cout << "Resources in the project:" << endl;
        cout << "x-------------------------------------------------------------------------x" << endl;
        cout << "Res ID\tName\tAvailable\tSkill ID\tSkill Name\tProficency" << endl;
        while (temp != NULL)
        {
            cout << temp->id << "\t" << temp->nameResouce << "\t" << (temp->available ? "Yes" : "No") << "\t\t" << temp->skill.id << "\t\t" << temp->skill.skillName << "\t\t" << temp->skill.proficency << endl;
            temp = temp->next;
        }
        cout << "x-------------------------------------------------------------------------x" << endl;
    }
    // Displaying Resources That are available
    void displayResourcesAvailable()
    {
        Resource *temp = headResource;
        if (temp == NULL)
        {
            cout << "No resources in the project." << endl;
            return;
        }
        while (temp != NULL)
        {
            if (temp->available == true)
            {
                cout << temp->id << "\t" << temp->nameResouce << "\t" << (temp->available ? "Yes" : "No") << "\t\t" << temp->skill.id << "\t\t" << temp->skill.skillName << "\t\t" << temp->skill.proficency << endl;
            }
            temp = temp->next;
        }
    }
};
// Generating a Unique Id
int generateUniqueID()
{
    static int id = 1;
    id++;
    return id;
}