// // Ali_Hamza_22i-2535 Assignment#02
#include <iostream>
#include <iomanip>
#include "Header.h"
#include <windows.h>
using namespace std;
// Adding Resources to p
void addResources(Project &p)
{
     system("CLS");
     p.addResources();
     cout << "Resources added Successfully..." << endl;
     Sleep(3000);
     system("CLS");
}
// Adding Tasks to p
void addTasks(Project &p)
{
     if (p.headResource == NULL)
     {
          cout << "You have to Add Resources First..." << endl;
          Sleep(3000);
          addResources(p);
     }
     system("CLS");
     p.addTasks();
     cout << "Tasks added Successfully..." << endl;
     Sleep(3000);
start2:
     system("CLS");
     cout << "x-----------------------------------------------------------------x" << endl;
     cout << "x  1- Calculate Basic Schedule                                    x" << endl;
     cout << "x  2- Calculate Schedule With Resources                           x" << endl;
     cout << "x  3- Calculate Schedule with Resources Proficency                x" << endl;
     cout << "x  4- Display Resources                                           x" << endl;
     cout << "x  5- Display Tasks                                               x" << endl;
     cout << "x  6- Display Tasks Dependencies                                  x" << endl;
     cout << "x  7- Exit                                                        x" << endl;
     cout << "x-----------------------------------------------------------------x" << endl;
     int choice;
     do
     {
          cout << "Choose : ";
          cin >> choice;
     } while (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && choice != 6 && choice != 7);
     switch (choice)
     {
     case 1:
          system("CLS");
          p.calculateBasicSchedule();
          p.printBasicSchedule();
          cout << endl;
          int choose;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose;
          } while (choose != 0);
          goto start2;
          break;
     case 2:
          system("CLS");

          p.calculateBasicSchedule();
          p.cpmResources();
          p.displayCPM();
          int choose1;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose1;
          } while (choose1 != 0);
          goto start2;
          break;
     case 4:
          system("CLS");
          p.displayResources();
          int choose8;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose8;
          } while (choose8 != 0);
          goto start2;
          break;
     case 3:
          system("CLS");
          p.calculateBasicSchedule();
          p.cpmResources();
          p.cpmResourcesWithProf();
          p.displayCPM();
          int choose2;
          do
          {
               cout
                   << "Press 0 to Go Back : ";
               cin >> choose2;
          } while (choose2 != 0);
          goto start2;
          break;
     case 5:
          system("CLS");
          cout << "x------------------------------------------------------------------x" << endl;
          cout << "\tID\t\tName\t\tDuration" << endl;
          p.displayTasks();
          cout << "x------------------------------------------------------------------x" << endl;
          int choose3;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose3;
          } while (choose3 != 0);
          goto start2;
          break;
     case 6:
          system("CLS");
          p.printTaskDependencyList();
          int choose4;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose4;
          } while (choose4 != 0);
          goto start2;
          break;
     case 7:
          return;
          break;
     }
}
int main()
{
     Project p;
start:
     system("CLS");
     cout
         << "x------------------------------------------------------------------x" << endl;
     cout << "x  1- Add Resources                                               x" << endl;
     cout << "x  2- Add Tasks                                                   x" << endl;
     cout << "x  3- Display Resources                                           x" << endl;
     cout << "x  4- Exit Program                                                x" << endl;
     cout << "x-----------------------------------------------------------------x" << endl;
     int choice;
     do
     {
          cout << "Choose : ";
          cin >> choice;
     } while (choice != 1 && choice != 2 && choice != 3 && choice != 4);
     switch (choice)
     {
     case 1:
          addResources(p);
          goto start;
          break;
     case 2:
          addTasks(p);
          return 0;
          break;
     case 3:
          system("CLS");
          p.displayResources();
          int choose;
          do
          {
               cout << "Press 0 to Go Back : ";
               cin >> choose;
          } while (choose != 0);
          goto start;
     case 4:
          return 0;
          break;
     default:
          break;
     }

     return 0;
}
