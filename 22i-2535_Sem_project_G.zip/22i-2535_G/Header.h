// Ali_Hamza_G_22I-2535
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <Windows.h>
#include <conio.h>
using namespace std;
#define INT_MAX 10000
void displayMaze(int M, int N, char **maze);
class Cell
{
public:
    int i;
    int j;
    int weight;
    Cell()
    {
        weight = 1;
    }
    Cell(int i, int j)
    {
        this->i = i;
        this->j = j;
    }
};
class Stack
{
private:
    int maxSize;
    int *data;
    int topIndex;

public:
    Stack()
    {
        maxSize = 400;
        data = new int[maxSize];
        topIndex = -1;
    }

    void push(int value)
    {
        if (topIndex < maxSize - 1)
        {
            data[++topIndex] = value;
        }
        else
        {
            cout << "Cannot push into a full stack." << endl;
        }
    }
    bool isEmpty()
    {
        return topIndex == -1;
    }
    void pop()
    {
        if (!isEmpty())
        {
            --topIndex;
        }
        else
        {
            cout << "Cannot pop from an empty stack." << endl;
        }
    }

    int top()
    {
        if (!isEmpty())
        {
            return data[topIndex];
        }
        else
        {
            cout << "Stack is empty. No top element available." << endl;

            return 0;
        }
    }
};

// Node structure to represent elements in the queue
struct Node
{
    int data;
    Node *next;

    Node(int value) : data(value), next(nullptr) {}
};

// Queue class
class Queue
{
private:
    Node *front;
    Node *rear;

public:
    Queue()
    {
        front = NULL;
        rear = NULL;
    }
    void push(int value)
    {
        Node *newNode = new Node(value);
        if (rear == nullptr)
        {
            front = rear = newNode;
        }
        else
        {
            rear->next = newNode;
            rear = newNode;
        }
    }

    // Function to pop a value from the queue
    void pop()
    {
        if (isEmpty())
        {

            return;
        }
        Node *temp = front;
        front = front->next;
        if (front == nullptr)
        {
            rear = nullptr;
        }

        delete temp;
    }

    // Function to get the front (top) value of the queue
    int top()
    {
        if (isEmpty())
        {

            return -1; // Return a default value or handle the error accordingly
        }
        return front->data;
    }

    // Function to check if the queue is empty
    bool isEmpty()
    {
        return front == nullptr;
    }
};

class Graph
{
public:
    int **adjMatrix;
    int n;
    int m;
    Graph()
    {
    }
    Graph(int n, int m)
    {
        this->n = n;
        this->m = m;
        adjMatrix = new int *[n * m];
        for (int i = 0; i < n * m; i++)
        {
            adjMatrix[i] = new int[n * m];
        }

        for (int i = 0; i < n * m; i++)
        {
            for (int j = 0; j < n * m; j++)
            {
                adjMatrix[i][j] = 0;
            }
        }
    }

    void makeObstacle(int **intMaze, char **maze)
    {

        int obstacleCount = 0;
        obstacleCount = (m * 30) / 100;

        Queue q;

        for (int i = 0; i < obstacleCount; i++)
        {
            q.push(157);
        }

        int randI = rand() % m;
        int randJ = rand() % n;
        int pathLength;
        Cell *shortestPath = findShortest(intMaze, pathLength, 1, 1);
        makeMazeWithShortest(m, n, maze, shortestPath, pathLength);
        while (!q.isEmpty())
        {
            while (maze[randI][randJ] != ' ')
            {
                randI = rand() % m;
                randJ = rand() % n;
            }

            maze[randI][randJ] = char(q.top());
            q.pop();
            randI = rand() % m;
            randJ = rand() % n;
        }

        resetMaze(m, n, maze);
    }
    void makePowerUps(int **intMaze, char **maze)
    {

        int powerCount = 0;
        powerCount = (m * 15) / 100;

        Queue q;
        for (int i = 0; i < powerCount; i++)
        {
            q.push(36);
        }

        int randI = rand() % m;
        int randJ = rand() % n;
        while (!q.isEmpty())
        {
            while (maze[randI][randJ] != ' ')
            {
                randI = rand() % m;
                randJ = rand() % n;
            }

            maze[randI][randJ] = char(q.top());
            q.pop();
            randI = rand() % m;
            randJ = rand() % n;
        }
    }

    bool manualMove(int **intMaze, char **maze, int &score, int &distanceMinus)
    {
        int currentScore = 0;
        int i = 1, j = 1;
        char ch = ' ';
        int pathLength;
        findShortest(intMaze, pathLength, i, j);
        int counter = 0;

        while (ch != 'e')
        {
            system("CLS");
            if (maze[m - 1][n - 2] == 'C')
            {
                if (pathLength + 15 < counter)
                {
                    distanceMinus = counter - pathLength;
                }
                score += currentScore;
                return true;
            }
            if (currentScore < 0)
            {
                currentScore = 0;
            }
            cout << "============================================================================================================" << endl;
            cout << "                                     currentScore  :  " << currentScore << endl;
            cout << "============================================================================================================" << endl;
            maze[i][j] = 'C';
            displayMaze(m, n, maze);
            cout << "\nEnter W/S/D/A (Q to quit): " << endl;
            if (!_kbhit())
            {
                ch = _getch();
                switch (ch)
                {
                case 'w':

                    if (maze[i - 1][j] == ' ' || maze[i - 1][j] == '$' || maze[i - 1][j] == char(157) || maze[i - 1][j] == 'E')
                    {
                        if (maze[i - 1][j] == '$')
                        {
                            currentScore += 10;
                        }
                        else if (maze[i - 1][j] == char(157))
                        {
                            currentScore -= 5;
                        }

                        maze[i][j] = ' ';
                        maze[i - 1][j] = 'C';

                        i = i - 1;
                    }

                    break;
                case 's':
                    if (maze[i + 1][j] == ' ' || maze[i + 1][j] == '$' || maze[i + 1][j] == char(157) || maze[i + 1][j] == 'E')
                    {
                        if (maze[i + 1][j] == '$')
                        {
                            currentScore += 10;
                        }
                        else if (maze[i + 1][j] == char(157))
                        {
                            currentScore -= 5;
                        }
                        maze[i][j] = ' ';
                        maze[i + 1][j] = 'C';

                        i = i + 1;
                    }

                    break;
                case 'a':
                    if (maze[i][j - 1] == ' ' || maze[i][j - 1] == '$' || maze[i][j - 1] == char(157) || maze[i][j - 1] == 'E')
                    {
                        if (maze[i][j - 1] == '$')
                        {
                            currentScore += 10;
                        }
                        else if (maze[i][j - 1] == char(157))
                        {
                            currentScore -= 5;
                        }
                        maze[i][j] = ' ';
                        maze[i][j - 1] = 'C';

                        j = j - 1;
                    }

                    break;
                case 'd':
                    if (maze[i][j + 1] == ' ' || maze[i][j + 1] == '$' || maze[i][j + 1] == char(157) || maze[i][j + 1] == 'E')
                    {
                        if (maze[i][j + 1] == '$')
                        {
                            currentScore += 10;
                        }
                        else if (maze[i][j + 1] == char(157))
                        {
                            currentScore -= 5;
                        }
                        maze[i][j] = ' ';
                        maze[i][j + 1] = 'C';

                        j = j + 1;
                    }
                    break;
                case 'e':
                    return false;
                default:
                    break;
                }
                counter++;
            }
        }
    }
    void semiAutoMove(char **maze, int **intMaze)
    {
        int i = 1, j = 1;
        char ch = ' ';
        int pathLength;
        Cell *shortestPath = findShortest(intMaze, pathLength, i, j);

        while (ch != 'e')
        {
            system("CLS");
            if (maze[m - 1][n - 2] == 'C')
            {
                return;
            }
            maze[i][j] = 'C';
            resetMaze(m, n, maze);
            makeMazeWithShortest(m, n, maze, shortestPath, pathLength);
            maze[i][j] = 'C';
            displayMaze(m, n, maze);
            cout << "\nEnter W/S/D/A (Q to quit): " << endl;
            if (!_kbhit())
            {
                ch = _getch();
                switch (ch)
                {
                case 'w':

                    if (maze[i - 1][j] == ' ' || maze[i - 1][j] == '*' || maze[i - 1][j] == '$' || maze[i - 1][j] == char(157) || maze[i - 1][j] == 'E')
                    {
                        maze[i][j] = ' ';
                        maze[i - 1][j] = 'C';
                        i = i - 1;
                    }

                    break;
                case 's':
                    if (maze[i + 1][j] == ' ' || maze[i + 1][j] == '*' || maze[i + 1][j] == '$' || maze[i + 1][j] == char(157) || maze[i + 1][j] == 'E')
                    {
                        maze[i][j] = ' ';
                        maze[i + 1][j] = 'C';
                        i = i + 1;
                    }

                    break;
                case 'a':
                    if (maze[i][j - 1] == ' ' || maze[i][j - 1] == '*' || maze[i][j - 1] == '$' || maze[i][j - 1] == char(157) || maze[i][j - 1] == 'E')
                    {
                        maze[i][j] = ' ';
                        maze[i][j - 1] = 'C';
                        j = j - 1;
                    }

                    break;
                case 'd':
                    if (maze[i][j + 1] == ' ' || maze[i][j + 1] == '*' || maze[i][j + 1] == '$' || maze[i][j + 1] == char(157) || maze[i][j + 1] == 'E')
                    {
                        maze[i][j] = ' ';
                        maze[i][j + 1] = 'C';
                        j = j + 1;
                    }

                    break;
                case 'e':
                    return;
                default:

                    break;
                }

                shortestPath = findShortest(intMaze, pathLength, i, j);
            }
        }
        return;
    }

    int minDistance(int dist[], bool sptSet[], int V)
    {
        int min = INT_MAX, min_index;

        for (int v = 0; v < V; v++)
        {
            if (!sptSet[v] && dist[v] <= min)
            {
                min = dist[v];
                min_index = v;
            }
        }

        return min_index;
    }

    void printPath(int parent[], int j, int V)
    {

        if (parent[j] == -1)
        {
            cout << "(" << j / V << ", " << j % V << ") ";
            return;
        }

        printPath(parent, parent[j], V);
        cout << "(" << j / V << ", " << j % V << ") ";
    }

    void printSolution(int dist[], int parent[], int src, int dest, int V)
    {
        cout << "Shortest Path from (" << src / V << ", " << src % V << ") to (" << dest / V << ", " << dest % V << "):\n";
        cout << "Shortest Path: ";
        printPath(parent, dest, V);
        cout << "\nDistance: " << dist[dest] << endl;
    }

    void dijkstra(int **graph, Cell src, Cell dest, int V, Cell *&shortestPath, int &pathLength)
    {
        int *dist = new int[V];
        bool *sptSet = new bool[V];
        int *parent = new int[V];

        for (int i = 0; i < V; i++)
        {
            dist[i] = INT_MAX;
            sptSet[i] = false;
            parent[i] = -1;
        }

        int srcVertex = src.i * n + src.j;
        int destVertex = dest.i * n + dest.j;

        dist[srcVertex] = 0;

        for (int count = 0; count < V - 1; count++)
        {
            int u = minDistance(dist, sptSet, V);

            sptSet[u] = true;

            for (int v = 0; v < V; v++)
            {
                if (!sptSet[v] && graph[u][v] && dist[u] != INT_MAX &&
                    dist[u] + graph[u][v] < dist[v])
                {
                    dist[v] = dist[u] + graph[u][v];
                    parent[v] = u;
                }
            }
        }

        pathLength = 0;
        int current = destVertex;
        while (current != -1)
        {
            pathLength++;
            current = parent[current];
        }

        shortestPath = new Cell[pathLength];

        current = destVertex;
        for (int i = pathLength - 1; i >= 0; i--)
        {
            shortestPath[i].i = current / n;
            shortestPath[i].j = current % n;
            current = parent[current];
        }
    }

    Cell *findShortest(int **maze, int &path, int si, int sj)
    {
        Cell src, dest;
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (maze[i][j] == 1)
                {
                    dest.i = i;
                    dest.j = j;
                }
            }
        }

        src.i = si;
        src.j = sj;

        Cell *shortestPath = nullptr;
        int pathLength = 0;

        dijkstra(adjMatrix, src, dest, m * n, shortestPath, pathLength);
        path = pathLength;
        return shortestPath;
    }
    void autoMove(char **maze, int **intMaze)
    {
        int pathLenght;
        Cell *shortestPath = findShortest(intMaze, pathLenght, 1, 1);

        for (int i = 0; i < pathLenght; i++)
        {
            if (maze[shortestPath[i].i][shortestPath[i].j] == '$' || maze[shortestPath[i].i][shortestPath[i].j] == char(157))
            {
            }
            else
            {
                maze[shortestPath[i].i][shortestPath[i].j] = '*';
            }
        }
        int k = 0;
        int fi = shortestPath[k].i, fj = shortestPath[k].j;
        maze[fi][fj] = 'C';
        while (k < pathLenght)
        {
            displayMaze(m, n, maze);
            maze[fi][fj] = ' ';
            fi = shortestPath[k].i;
            fj = shortestPath[k].j;
            k++;
            maze[fi][fj] = 'C';
            Sleep(500);
            system("CLS");
        }
    }

    void makeAdjancenyMatrix(int **maze)
    {
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (maze[i][j] == 1)
                {
                    if (maze[i + 1][j] == 1)
                    {
                        adjMatrix[getPostion(i, j)][getPostion(i + 1, j)] = 1;
                    }
                    if (maze[i - 1][j] == 1)
                    {
                        adjMatrix[getPostion(i, j)][getPostion(i - 1, j)] = 1;
                    }
                    if (maze[i][j + 1] == 1)
                    {
                        adjMatrix[getPostion(i, j)][getPostion(i, j + 1)] = 1;
                    }
                    if (maze[i][j - 1] == 1)
                    {
                        adjMatrix[getPostion(i, j)][getPostion(i, j - 1)] = 1;
                    }
                }
            }
        }
    }

    int getPostion(int i, int j)
    {
        return i * n + j;
    }
    void resetMaze(int m, int n, char **maze)
    {
        for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (maze[i][j] == '*')
                {
                    maze[i][j] = ' ';
                }
            }
        }
    }
    void makeMazeWithShortest(int m, int n, char **maze, Cell *shortestPath, int pathLength)
    {
        int k = 0;

        while (k < pathLength)
        {
            if (maze[shortestPath[k].i][shortestPath[k].j] == '$' || maze[shortestPath[k].i][shortestPath[k].j] == char(154))
            {
            }
            else
            {
                maze[shortestPath[k].i][shortestPath[k].j] = '*';
            }

            k++;
        }
    }
};

void createIntMaze(char **maze, int **intMaze, int N, int M)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (maze[i][j] == ' ')
            {
                intMaze[i][j] = 1;
            }
            else
            {
                intMaze[i][j] = 0;
            }
        }
    }
}

void displayMaze(int M, int N, char **maze)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            cout << maze[i][j] << " ";
        }
        cout << endl;
    }
}
void displayMazeInt(int M, int N, int **maze)
{
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            cout << maze[i][j] << " ";
        }
        cout << endl;
    }
}

int getLoc(int x, int y, Cell nodes[], int size)
{
    for (int i = 0; i < size; i++)
    {
        if (nodes[i].i == x && nodes[i].j == y)
            return i;
    }
    cout << "Could not find the index!" << endl;
    return -1;
}

void createMaze(int M, int N, char **maze, int m, int n)
{
    const int maxSize = 400;

    Cell nodes[maxSize];
    bool visited[maxSize] = {false};
    Stack stack;
    srand(time(NULL));

    int nVisited = 0;
    int k = 0;

    for (int i = 1; i < M; i += 2)
    {
        for (int j = 1; j < N; j += 2)
        {
            nodes[k].i = i;
            nodes[k].j = j;
            k++;
        }
    }

    int randIndex = rand() % (m * n);

    stack.push(randIndex);
    visited[randIndex] = true;
    nVisited++;

    while (nVisited < m * n)
    {
        int neighbours[4] = {0, 0, 0, 0};
        int currentCell = stack.top();
        int x = nodes[currentCell].i;
        int y = nodes[currentCell].j;

        if (x > 1)
        {
            if (maze[x - 2][y] && !visited[getLoc(x - 2, y, nodes, m * n)])
            {
                neighbours[0] = 1;
            }
        }

        if (y < N - 2)
        {
            if (maze[x][y + 2] && !visited[getLoc(x, y + 2, nodes, m * n)])
            {
                neighbours[1] = 1;
            }
        }

        if (x < M - 2)
        {
            if (maze[x + 2][y] && !visited[getLoc(x + 2, y, nodes, m * n)])
            {
                neighbours[2] = 1;
            }
        }

        if (y > 1)
        {
            if (maze[x][y - 2] && !visited[getLoc(x, y - 2, nodes, m * n)])
            {
                neighbours[3] = 1;
            }
        }

        if (neighbours[0] || neighbours[1] || neighbours[2] || neighbours[3])
        {

            int nextDir;
            do
            {
                nextDir = rand() % 4;
            } while (neighbours[nextDir] == 0);

            switch (nextDir)
            {
            case 0:
                maze[x - 1][y] = ' ';
                stack.push(getLoc(x - 2, y, nodes, m * n));
                break;
            case 1:
                maze[x][y + 1] = ' ';
                stack.push(getLoc(x, y + 2, nodes, m * n));
                break;
            case 2:
                maze[x + 1][y] = ' ';
                stack.push(getLoc(x + 2, y, nodes, m * n));
                break;
            case 3:
                maze[x][y - 1] = ' ';
                stack.push(getLoc(x, y - 2, nodes, m * n));
                break;
            }

            visited[stack.top()] = true;
            nVisited++;
        }
        else
        {
            stack.pop();
        }
    }
    maze[0][1] = 'S';
    maze[2 * m][2 * n - 1] = 'E';
}
