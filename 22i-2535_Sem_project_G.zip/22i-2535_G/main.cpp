// Ali_Hamza_G_22I-2535
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Header.h"
#include <fstream>
#include <sstream>

using namespace std;

struct User
{
    string username;
    string password;
    int score;
};
void mainMenu();
void startGame(int &score, string &username, string &password);
void registerUser();
bool loginUser(string &currentUsername, string &password, int &currentScore);
void updateUserScores(const User &user);
void displayMyScore(string &loggedInUser);

int main()
{
    int choice;
    string currentUsername;
    string currentPassword;
    int currentScore = 0;

    do
    {
        Sleep(3000);
        system("CLS");
        mainMenu();
        cin >> choice;

        switch (choice)
        {
        case 1:
            if (loginUser(currentUsername, currentPassword, currentScore))
            {
                startGame(currentScore, currentUsername, currentPassword);
                updateUserScores({currentUsername, currentPassword, currentScore});
            }
            break;
        case 2:
            registerUser();
            break;
        case 3:
            startGame(currentScore, currentUsername, currentPassword);
            break;
        case 4:
            cout << "Exiting the game, Goodbye!" << endl;
            return 0;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }

    } while (choice != 4);

    return 0;
}
void mainMenu()
{
    system("CLS");
    cout << "============================================================================================================" << endl;
    cout << "                                     WELCOME TO THE MAZE EXPLORER GAME       " << endl;
    cout << "============================================================================================================" << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "                                            1. Login                        " << endl;
    cout << "                                            2. Registor                        " << endl;
    cout << "                                            3. Play as Guest                    " << endl;
    cout << "                                            4. Exit                            " << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "============================================================================================================" << endl;
}
void makeMaze(int mode, int &score, int level)
{
    int m, n;
    if (level == 4)
    {
        cout << "Enter the dimension of maze you want (<1 and >21) : ";
        cin >> m >> n;
        while (m < 1 || n < 1)
        {
            cout << "Desired dimensions impossible. Re-enter pls." << endl;
            cin >> m >> n;
        }
    }
    else if (level == 3)
    {
        m = n = 17;
    }
    else if (level == 2)
    {
        m = n = 10;
    }
    else
    {
        m = n = 5;
    }
    int M = 2 * m + 1;
    int N = 2 * n + 1;
    char **maze;
    maze = new char *[M];

    for (int i = 0; i < M; i++)
    {
        maze[i] = new char[N];
    }

    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i % 2 == 0 || j % 2 == 0)
                maze[i][j] = char(254);
            else
                maze[i][j] = ' ';
        }
    }
    createMaze(M, N, maze, m, n);

    int **intMaze;
    intMaze = new int *[M];

    for (int i = 0; i < M; i++)
    {
        intMaze[i] = new int[N];
    }

    createIntMaze(maze, intMaze, N, M);
    Graph g(M, N);
    g.makeAdjancenyMatrix(intMaze);
    g.makeObstacle(intMaze, maze);
    g.makePowerUps(intMaze, maze);
    bool check;
    if (mode == 1)
    {
        int distance = 0;
        check = g.manualMove(intMaze, maze, score, distance);
        if (check == true)
        {
            cout << endl
                 << endl
                 << "\t\t\tYou have SuccessFully Completed level.." << endl;
            cout << "\t\t\tYou are given a bonus of " << level * 30 << " scores" << endl;
            score += (level * 30);
            if (distance > 0)
            {
                cout << "\t\t\tYou take extra " << distance << " Step : -" << distance / level << endl;
                score -= (distance / level);
            }
            cout << "\t\t\tTotal Score : " << score << endl;
            Sleep(4000);
        }
        else
        {
            cout << endl
                 << endl
                 << "\t\t\tBad Luck ! Try Next Time " << endl;
            cout << "\t\t\tScore : " << 0 << endl;
            score = 0;
            Sleep(4000);
        }
    }
    else if (mode == 2)
    {
        g.semiAutoMove(maze, intMaze);
    }
    else if (mode == 3)
    {
        g.autoMove(maze, intMaze);
    }
}
void difficultyLevel(int choice, int &score)
{
    system("CLS");
    int choiceLevel;
    cout << "============================================================================================================" << endl;
    cout << "                                     WELCOME TO THE MAZE EXPLORER GAME       " << endl;
    cout << "============================================================================================================" << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "                                            1. Easy                        " << endl;
    cout << "                                            2. Medium                     " << endl;
    cout << "                                            3. Hard                          " << endl;
    cout << "                                            4. Custom                          " << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "============================================================================================================" << endl;

    cin >> choiceLevel;
    makeMaze(choice, score, choiceLevel);
}
void playGame(int &score, string &username, string &password)
{
    int choice;

    system("CLS");
    cout << "============================================================================================================" << endl;

    cout << "                                     WELCOME TO THE MAZE EXPLORER GAME       " << endl;
    cout << "============================================================================================================" << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "                                            1. Manual Mode                        " << endl;
    cout << "                                            2. Semi Auto Mode                     " << endl;
    cout << "                                            3. Auto Mode                          " << endl;
    cout << endl
         << endl
         << endl
         << endl
         << endl;
    cout << "============================================================================================================" << endl;
    cin >> choice;
    difficultyLevel(choice, score);
    {
        updateUserScores({username, password, score});
    }
}
struct Player
{
    string Playername;
    string password;
    int score;
    Player *left;
    Player *right;
    Player() {}
    Player(const string &uname, const string &pwd, int scr)
        : Playername(uname), password(pwd), score(scr), left(nullptr), right(nullptr) {}
};

Player *insertPlayer(Player *root, const string &Playername, const string &password, int score)
{
    if (root == nullptr)
    {
        return new Player(Playername, password, score);
    }

    if (score > root->score)
    {
        root->right = insertPlayer(root->right, Playername, password, score);
    }
    else if (score < root->score)
    {
        root->left = insertPlayer(root->left, Playername, password, score);
    }

    return root;
}

void displayLeaderboardHelper(Player *root)
{
    if (root == nullptr)
    {
        return;
    }

    displayLeaderboardHelper(root->right);

    cout << "Playername: " << root->Playername << "\tScore: " << root->score << endl;

    displayLeaderboardHelper(root->left);
}

Player *buildLeaderboard(const string &filename)
{
    ifstream PlayerFile(filename);
    string line;
    Player *root = nullptr;

    while (getline(PlayerFile, line))
    {
        istringstream iss(line);
        Player player;
        iss >> player.Playername >> player.password >> player.score;
        root = insertPlayer(root, player.Playername, player.password, player.score);
    }

    return root;
}
void displayLeaderboard(Player *root)
{
    system("CLS");
    cout << "==================== LEADERBOARD ====================" << endl;
    displayLeaderboardHelper(root);
    cout << "======================================================" << endl;
}

void startGame(int &score, string &username, string &password)
{
    int choice;

    do
    {
        system("CLS");
        cout << "============================================================================================================" << endl;
        cout << "                                     WELCOME TO THE MAZE EXPLORER GAME       " << endl;
        cout << "============================================================================================================" << endl;
        cout << endl
             << endl
             << endl
             << endl
             << endl;
        cout << "                                            1. Play Game                        " << endl;
        cout << "                                            2. My Score                     " << endl;
        cout << "                                            3. Leaderboard                     " << endl;
        cout << "                                            4. Exit                            " << endl;
        cout << endl
             << endl
             << endl
             << endl
             << endl;
        cout << "============================================================================================================" << endl;
        cin >> choice;
        if (choice == 1)
        {

            playGame(score, username, password);
        }
        else if (choice == 2)
        {
            displayMyScore(username);
            Sleep(4000);
        }
        else if (choice == 3)
        {
            Player *leaderboard = buildLeaderboard("users.txt");
            displayLeaderboard(leaderboard);
            Sleep(4000);
        }
        else if (choice == 4)
        {
            return;
        }
        else
        {

            cout << "Invalid input ..." << endl;
            Sleep(2000);
        }

    } while (choice != 4);
}

void registerUser()
{
    string username, password;
    cout << "Enter a username: ";
    cin >> username;

    ifstream userFile("users.txt");
    string line;
    while (getline(userFile, line))
    {
        if (line.find(username) != string::npos)
        {
            cout << "Username already exists. Please choose a different one." << endl;
            return;
        }
    }

    cout << "Enter a password: ";
    cin >> password;

    ofstream userFileOut("users.txt", ios::app);
    userFileOut << username << " " << password << " 0" << endl;
    userFileOut.close();

    cout << "Registration successful! You can now log in." << endl;
}

bool loginUser(string &currentUsername, string &currentPassword, int &currentScore)
{
    string username, password;
    cout << "Enter your username: ";
    cin >> username;
    cout << "Enter your password: ";
    cin >> password;

    ifstream userFile("users.txt");
    string line;
    while (getline(userFile, line))
    {
        istringstream iss(line);
        User user;
        iss >> user.username >> user.password >> user.score;

        if (user.username == username && user.password == password)
        {
            cout << "Login successful! Welcome, " << username << "!" << endl;
            currentUsername = username;
            currentPassword = password;
            currentScore = user.score;
            Sleep(3000);
            return true;
        }
    }

    cout << "Invalid username or password. Please try again." << endl;
    return false;
}

void updateUserScores(const User &user)
{

    ifstream inFile("users.txt");
    ofstream outFile("temp.txt");

    string line;
    while (getline(inFile, line))
    {
        istringstream iss(line);
        string username;
        iss >> username;

        if (username == user.username)
        {
            outFile << user.username << " " << user.password << " " << user.score << endl;
        }
        else
        {
            outFile << line << endl;
        }
    }

    inFile.close();
    outFile.close();

    remove("users.txt");
    rename("temp.txt", "users.txt");
}

void displayMyScore(string &loggedInUser)
{
    system("CLS");
    cout << "==================== My Score ====================" << endl;

    ifstream userFile("users.txt");
    string line;
    while (getline(userFile, line))
    {
        istringstream iss(line);
        User user;
        iss >> user.username >> user.password >> user.score;

        if (user.username == loggedInUser)
        {
            cout << loggedInUser << " , Your Score: " << user.score << endl;
            break;
        }
    }

    cout << "======================================================" << endl;
}
