// Ali_Hamza_22i-2535  Assignment # 03
#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <sstream>
#include <fstream>
using namespace std;

class Node
{
public:
    string name;
    string path;
    string type;
    Node *left;
    Node *right;
    Node()
    {
        left = NULL;
        right = NULL;
    }
    Node(string name, string path, string type)
    {
        this->name = name;
        this->path = path;
        this->type = type;
        left = NULL;
        right = NULL;
    }
};
// BinaryTree class represents a binary tree
class BinaryTree
{
public:
    Node *root;
    BinaryTree()
    {
        root = NULL;
        createDefault();
    }
    void creatDirectory()
    {
        getValues("NULL");
    }
    void createFile()
    {
        getValues("file");
    }

    void renameFile()
    {
        string name, rename;
        cout << endl
             << "Enter the name of file : ";
        cin >> name;
        cout << endl
             << "Enter the new Name : ";
        cin >> rename;
        if (checkFileExist(root, name, rename))
        {
            cout << "File name changed Successfully !" << endl;
        }
        else
        {
            cout << "\nFolder with name " << name << " does not exist" << endl;
        }
    }
    void searchFile()
    {
        string name;
        cout << endl
             << "Enter the name of File : ";
        cin >> name;
        Node *temp = searchFile(root, name);
        if (temp == NULL)
        {
            cout << "\nFolder with name " << name << " does not exist" << endl;
        }
        else
        {
            cout << "Name : " << temp->name << endl;
            cout << "Type : " << temp->type << endl;
            cout << "Path : " << temp->path << endl;
        }
    }

    Node *searchFile(Node *root, string name)
    {
        if (root == NULL)
        {
            return NULL;
        }
        if (root->name == name)
        {
            return root;
        }
        Node *left = searchFile(root->left, name);
        Node *right = searchFile(root->right, name);
        if (left == NULL)
        {
            return right;
        }
        else
        {
            return left;
        }
        return NULL;
    }

    bool checkFileExist(Node *root, string name, string rename)
    {
        if (root == NULL)
        {
            return false;
        }
        if (root->name == name)
        {
            root->name = rename;
            return true;
        }
        return checkFileExist(root->left, name, rename) || checkFileExist(root->right, name, rename);
    }

    void mergeFile()
    {
        string source, dest;
        cout << endl
             << "Enter the source : ";
        cin >> source;
        cout << endl
             << "Enter the destination : ";
        cin >> dest;

        if (checkDestFolderFull(root, dest))
        {
            int choice;
            cout << "Destination folder is Full.\n1- Replace\n2- Abort\n";
            cin >> choice;
            if (choice == 1)
            {
                Node *temp = getSourceFile(root, source);
                updateFileAtDest(root, dest, temp);
                root = DeleteComp(root, source);
            }
            else
            {
                cout << endl
                     << "Aborted..." << endl;
            }
        }
        else
        {
            Node *temp = getSourceFile(root, source);
            updateFileAtDest(root, dest, temp);
            root = DeleteComp(root, source);
        }
    }
    void moveFile()
    {

        string source, dest;
        cout << endl
             << "Enter the source folder of file to move : ";
        cin >> source;
        cout << endl
             << "Enter the destination folder of file to move : ";
        cin >> dest;

        if (checkDestFolderFull(root, dest))
        {
            cout << "Destination is alreay Full. Cannot move..." << endl;
        }
        else
        {
            Node *temp = getSourceFile(root, source);
            root = Delete(root, temp->name);
            cout << temp->name << endl;
            updateFileAtDest(root, dest, temp);
        }
    }
    void updateFileAtDest(Node *root, string name, Node *temp)
    {
        if (root == NULL)
        {
            return;
        }
        if (root->name == name)
        {
            root->right = temp;
        }
        updateFileAtDest(root->left, name, temp);
        updateFileAtDest(root->right, name, temp);
    }

    Node *getSourceFile(Node *root, string name)
    {
        if (root == NULL)
        {
            return NULL;
        }
        if (root->name == name)
        {
            return root->right;
        }
        Node *left = getSourceFile(root->left, name);
        Node *right = getSourceFile(root->right, name);
        if (left == NULL)
        {
            return right;
        }
        else
        {
            return left;
        }
        return NULL;
    }
    bool checkDestFolderFull(Node *root, string name)
    {
        if (root == NULL)
        {
            return false;
        }
        if (root->right != NULL && root->name == name)
        {
            return true;
        }

        return checkDestFolderFull(root->left, name) || checkDestFolderFull(root->right, name);
    }
    void deleteFile()
    {
        string name;
        cout << "Enter the name  : ";
        cin >> name;
        if (checkFileOrFold(root, name))
        {
            if (checkNoChild(root, name))
            {
                root = Delete(root, name);
            }
            else
            {
                int choose;
                cout << "Cannot delete a non Empty Directory" << endl;
                cout << "Do you want cascade Delete : \n1- Yes\n2- No\nchoose  : ";
                cin >> choose;
                if (choose == 1)
                {
                    root = DeleteComp(root, name);
                }
            }
        }
        else
        {
            root = Delete(root, name);
        }
    }
    // Function to delete a node along with its children
    Node *DeleteComp(Node *root, string name)
    {
        if (root == NULL)
        {
            return NULL;
        }
        if (root->name == name)
        {
            return root->left;
        }
        root->left = DeleteComp(root->left, name);
        root->right = DeleteComp(root->right, name);
        return root;
    }
    // Function to check if a node has no child nodes
    bool checkNoChild(Node *root, string name)
    {
        if (root == NULL)
        {
            return false;
        }
        if (root->left == NULL && root->right == NULL && root->name == name)
        {
            return true;
        }

        return checkNoChild(root->left, name) || checkNoChild(root->right, name);
    }
    // Function to check if a file or folder with a given name exists in the tree
    bool checkFileOrFold(Node *root, string name)
    {
        if (root == NULL)
        {
            return false;
        }
        if (root->type == "NULL" && root->name == name)
        {
            return true;
        }

        return checkFileOrFold(root->left, name) || checkFileOrFold(root->right, name);
    }
    Node *Delete(Node *root, string name)
    {
        if (root == NULL)
        {
            return NULL;
        }
        if (root->name == name)
        {
            return NULL;
        }
        root->left = Delete(root->left, name);
        root->right = Delete(root->right, name);
        return root;
    }
    // Function to create default directories in the tree
    void createDefault()
    {
        root = new Node("/", "", "NULL");
        root->left = new Node("PatientsData", "/", "NULL");
        root->right = new Node("Logs", "/", "NULL");
    }
    // Function to check if a tree with a given path exists in the tree
    bool checkTreeExist(Node *root, string path)
    {
        if (root == NULL)
        {
            return false;
        }

        if (root->path == path)
        {
            return true;
        }

        return checkTreeExist(root->left, path) || checkTreeExist(root->right, path);
    }
    // Function to check if the home directory is full

    bool checkHomeFull(Node *root)
    {
        Node *temp = root;
        while (temp->left != NULL)
        {
            temp = temp->left;
        }
        if (temp->right == NULL)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    // Function to insert a node into the home directory
    void insertHomeFile(Node *root, Node *temp1)
    {
        Node *temp = root;
        while (temp->left != NULL)
        {
            temp = temp->left;
        }
        temp->right = temp1;
    }
    // Function to check if a path is full in the tree
    bool checkPathFull(Node *root, string temp)
    {
        if (root == NULL)
        {
            return true;
        }
        if (root->path == temp)
        {
            if (root->right == NULL)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        return checkPathFull(root->left, temp) && checkPathFull(root->right, temp);
    }

    // Function to search and insert a node into the tree
    Node *searchAndInsert(Node *root, Node *temp, string path)
    {
        if (root == NULL)
        {
            return NULL;
        }
        if (root->path == path)
        {
            root->right = temp;
        }
        root->left = searchAndInsert(root->left, temp, path);
        root->right = searchAndInsert(root->right, temp, path);
        return root;
    }
    void checkPath(Node *temp)
    {
        vector<string> parseP;
        istringstream iss(temp->path);
        string token;

        parseP.push_back("/");
        while (getline(iss, token, '/'))
        {
            if (!token.empty())
            {
                parseP.push_back(token);
            }
        }
        string tempString;
        for (int i = 0; i < parseP.size() - 1; i++)
        {
            tempString += parseP[i];

            if (i != 0 && i < parseP.size() - 2)
                tempString += "/";
        }
        string tempString2;
        for (int i = 0; i < parseP.size() - 2; i++)
        {
            tempString2 += parseP[i];

            if (i != 0 && i < parseP.size() - 3)
                tempString2 += "/";
        }
        if (checkTreeExist(root, tempString))
        {

            if (tempString == "/PatientsData")
            {
                if (checkHomeFull(root->left))
                {
                    cout << "Cannot Add.Home Directory is Full" << endl;
                }
                else
                {
                    insertHomeFile(root->left, temp);
                }
            }
            else if (tempString == "/Logs")
            {
                if (checkHomeFull(root->right))
                {
                    cout << "Cannot Add.Log Directory is Full" << endl;
                }
                else
                {
                    insertHomeFile(root->right, temp);
                }
            }
            else
            {
                if (checkPathFull(root, tempString2))
                {
                    cout << "The folder with given path is already Full..." << endl;
                }
                else
                {
                    searchAndInsert(root, temp, tempString2);
                }
            }
        }
        else
        {
            cout << "Path Does Not exist" << endl;
        }
    }

    // Function to insert a directory node into the tree
    Node *insertDirectory(Node *root, Node *temp)
    {
        if (root == NULL)
        {
            return temp;
        }
        temp->path = temp->path + "/" + root->name;
        root->left = insertDirectory(root->left, temp);
    }
    void getValues(string type)
    {
        string name, path, types;
        cout << endl
             << "Enter the name : ";
        cin >> name;

        if (type == "NULL")
        {
            int choose;
            cout << endl
                 << "Select thr Directoy Home : \n \n1- Patient Home\n2- Logs\nChoose : ";
            cin >> choose;
            if (choose == 1)
            {
                insertDirectory(root->left, new Node(name, path, type));
            }
            else
            {
                insertDirectory(root->right, new Node(name, path, type));
            }
        }
        else
        {
            cout << endl
                 << "Enter the path : ";
            cin >> path;
            cout << "Enter the Type of the File : ";
            cin >> types;
            checkPath(new Node(name, path + "/" + name, types));
        }
    }
    // Function to update the tree after importing from a file
    void getValuesImport(string type, string name, string path)
    {
        string path1;

        if (type == "NULL")
        {
            size_t foundPos = path.find("PatientsData");
            size_t foundPos2 = path.find("Logs");

            if (foundPos != std::string::npos)
            {
                insertDirectory(root->left, new Node(name, path1, type));
            }
            else if (foundPos2 != std::string::npos)
            {
                insertDirectory(root->right, new Node(name, path1, type));
            }
            levelOrderTraversal(root);
        }
        else
        {
            checkPath(new Node(name, path, type));
        }
    }
    // Function to export the tree to a file
    void exportToFile(const string &filename)
    {
        ofstream outFile(filename);
        if (!outFile.is_open())
        {
            cout << "File did not open ! " << endl;
            return;
        }
        exportTree(root, outFile);
        outFile.close();
        cout << "Tree exported to " << filename << " successfully." << endl;
    }

    void exportTree(Node *root, ofstream &outFile)
    {
        if (root == nullptr)
        {
            return;
        }
        outFile << "Name: " << root->name << endl;
        outFile << "Path: " << root->path << endl;
        outFile << "Type: " << root->type << endl;
        exportTree(root->left, outFile);
        exportTree(root->right, outFile);
    }
    // Function to import the tree from a file
    void importFromFile(string &filename)
    {
        ifstream inFile(filename);
        if (!inFile.is_open())
        {
            cout << "File did not open." << endl;
            return;
        }
        clearTree(root);
        createDefault();
        while (!inFile.eof())
        {
            string name, path, type;
            getline(inFile, name);
            getline(inFile, path);
            getline(inFile, type);

            if (!name.empty() && !path.empty() && !type.empty())
            {

                name = name.substr(6);

                path = path.substr(6);

                type = type.substr(6);
                cout << name << endl;
                if (path == "" || path == "/")
                {
                }
                else
                {
                    getValuesImport(type, name, path);
                }
            }
        }
        inFile.close();
        cout << "Tree imported from " << filename << " successfully !" << endl;
    }

    void clearTree(Node *&root)
    {
        if (root == nullptr)
        {
            return;
        }

        clearTree(root->left);
        clearTree(root->right);
        delete root;
        root = nullptr;
    }
    // Function to perform level-order traversal

    void levelOrderTraversal(Node *root)
    {
        if (root == nullptr)
        {
            return;
        }

        queue<Node *> nodeQueue;
        nodeQueue.push(root);
        while (!nodeQueue.empty())
        {
            int levelSize = nodeQueue.size();

            for (int i = 0; i < levelSize; ++i)
            {
                Node *current = nodeQueue.front();
                nodeQueue.pop();

                cout << current->name << " ";

                if (current->left != nullptr)
                {
                    nodeQueue.push(current->left);
                }

                if (current->right != nullptr)
                {
                    nodeQueue.push(current->right);
                }
            }

            cout << endl;
        }
    }
};