// Ali_Hamza_22i-2535  Assignment # 03
#include <iostream>
#include "Header.h"
#include <Windows.h>
using namespace std;

int main()
{
    BinaryTree tree;

    int choose;
    while (1)
    {
        cout << "\n1- Create Directory\n2- Create File\n3- Delete File/Folder\n4- Merge Folder\n5- Rename Folder/File\n6- Search File\n7- Move File\n8- Export\n9- Import\n10- Display Level Order\n11- Exit\nChoose : ";
        cin >> choose;
        if (choose == 1)
        {
            tree.creatDirectory();
            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 2)
        {
            tree.createFile();
            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 3)
        {
            tree.deleteFile();
            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 4)
        {
            tree.mergeFile();
            tree.levelOrderTraversal(tree.root);
        }
        else if (choose == 5)
        {
            tree.renameFile();

            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 6)
        {
            tree.searchFile();
        }
        else if (choose == 7)
        {
            tree.moveFile();

            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 8)
        {
            string filename;
            cout << "Enter the filename for export: ";
            cin >> filename;
            tree.exportToFile(filename);
        }
        else if (choose == 9)
        {
            string filename;
            cout << "Enter the filename for import: ";
            cin >> filename;
            tree.importFromFile(filename);
        }

        else if (choose == 10)
        {
            system("CLS");
            tree.levelOrderTraversal(tree.root);
            Sleep(2000);
            system("CLS");
        }
        else if (choose == 11)
        {
            return 0;
        }
    }
}