// ALi_Hamza_22I-2535

#include <iostream>
#include "Header.h"
#include <string>
using namespace std;

int main()
{
    Employee employees[10];
    getDataFromFile(employees);

    // analysisScene01(employees, 10);
    // analysisScene02<int>(employees, 10);
    //  analysisScene03(employees, 10);
    //  analysisScene04(employees, 10);
    // analysisScene05(employees, 10);

    return 0;
}