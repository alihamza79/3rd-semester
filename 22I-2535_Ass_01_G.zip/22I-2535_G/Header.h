// ALi_Hamza_22I-2535

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <chrono>
using namespace std;

struct Employee
{
    string name;
    string id;
    int salary;
    int date[3];
    int year;
    string desig;
};

void getDataFromFile(Employee employees[])
{
    int i = 0;
    ifstream file("Employeedata.txt");
    if (!file.is_open())
    {
        cout << "Cannot open the file!" << endl;
        return;
    }
    string line;

    while (getline(file, line))
    {
        int colon = line.find(":");
        if (line.find("Employee Name") != string::npos)
        {
            employees[i].name = line.substr(colon + 1);
        }
        else if (line.find("Employee ID") != string::npos)
        {
            employees[i].id = line.substr(colon + 1);
        }
        else if (line.find("Salary") != string::npos)
        {
            string salary = line.substr(colon + 1);
            string newSal = "";
            for (int j = 0; j < salary.length(); j++)
            {
                if (salary[j] != '$' && salary[j] != ',')
                {
                    newSal += salary[j];
                }
            }
            employees[i].salary = stod(newSal);
        }
        else if (line.find("Date of Joining") != string::npos)
        {
            string dateStr = line.substr(colon + 1);
            string year = "", month = "", day = "";
            for (int i = 0; i < 5; i++)
            {
                if (dateStr[i] != '-')
                {
                    year += dateStr[i];
                }
            }
            for (int i = 5; i < 8; i++)
            {
                if (dateStr[i] != '-')
                {
                    month += dateStr[i];
                }
            }
            for (int i = 8; i < 11; i++)
            {
                if (dateStr[i] != '-')
                {
                    day += dateStr[i];
                }
            }
            employees[i].date[0] = stoi(year);
            employees[i].date[1] = stoi(month);
            employees[i].date[2] = stoi(day);
            employees[i].year = 2023 - employees[i].date[0];
        }
        else if (line.find("Designation") != string::npos)
        {
            employees[i].desig = line.substr(colon + 1);
            i++;
        }
    }
    file.close();
}

void analysisScene01(Employee employees[], int size)
{

    int total = 0;
    for (int i = 0; i < size; i++)
    {
        total += employees[i].salary;
    }
    int average = total / size;
    cout << "Average salary in the company is  : " << average << endl;
    cout << "Total number of employees is : " << size << endl;
    int years = 0;
    for (int i = 0; i < size; i++)
    {
        years += employees[i].year;
    }
    int averageYear = years / size;
    cout << "Average tenure in the company is  : " << averageYear << " years" << endl;
    // Base of the postion
    cout << endl
         << endl
         << "Software Engineers : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Software Engineer")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << " Senior Software Engineer : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Software Engineer")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << "  Data Scientist : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Data Scientist")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << " Project Manager : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Project Manager")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << " Senior Data Analyst : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Data Analyst")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << " UX Designer : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " UX Designer")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
    cout << endl
         << endl
         << " Quality Assurance Analyst : " << endl
         << endl;
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Quality Assurance Analyst")
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }

    // Employee with longest Tenure

    int max = INT16_MIN;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].year > max)
        {
            max = employees[i].year;
        }
    }
    cout << endl
         << endl
         << "Employee with longest tenure is : " << endl
         << endl;

    for (int i = 0; i < size; i++)
    {
        if (employees[i].year == max)
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
}
template <typename T>
void analysisScene02(Employee employees[], int size)
{
    int max = INT16_MIN;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].salary > max)
        {
            max = employees[i].salary;
        }
    }

    cout << endl
         << "Highest salary in the company is : $" << max << endl;

    int min = INT16_MAX;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].salary < min)
        {
            min = employees[i].salary;
        }
    }

    cout << endl
         << "Lowest salary in the company is : $" << min << endl;
    cout << endl
         << "Salary range in the company is : $" << max - min << endl;

    int arr[10];
    for (int i = 0; i < size; i++)
    {
        arr[i] = employees[i].salary;
    }
    sort(arr, arr + size);
    int median;
    if (size % 2 == 1)
    {
        median = employees[size / 2].salary; // Odd number of values
    }
    else
    {
        median = (employees[size / 2 - 1].salary + employees[size / 2].salary) / 2; // Even number of values
    }
    cout << endl
         << "Median salary in the company is : $" << median << endl;
    int totalSE = 0, totalDS = 0, totalSSE = 0, totalPM = 0, totalUD = 0, totalQA = 0, totalSDA = 0;
    int count[7] = {};
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Software Engineer")
        {
            totalSE += employees[i].salary;
            count[0]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Software Engineer")
        {
            totalSSE += employees[i].salary;
            count[1]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Data Scientist")
        {
            totalDS += employees[i].salary;
            count[2]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Project Manager")
        {
            totalPM += employees[i].salary;
            count[3]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Data Analyst")
        {
            totalSDA += employees[i].salary;
            count[4]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " UX Designer")
        {
            totalUD += employees[i].salary;
            count[5]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Quality Assurance Analyst")
        {
            totalQA += employees[i].salary;
            count[6]++;
        }
    }

    cout << endl
         << "Average salary of Software Engineer is : " << totalSE / count[0] << endl;
    cout << endl
         << "Average salary of Senior Software Engineer is : " << totalSSE / count[1] << endl;
    cout << endl
         << "Average salary of Data Sceintist is : " << totalDS / count[2] << endl;
    cout << endl
         << "Average salary of Project Manager is : " << totalPM / count[3] << endl;
    cout << endl
         << "Average salary of Senior Data Analyst is : " << totalSDA / count[4] << endl;
    cout << endl
         << "Average salary of UX Designer is : " << totalUD / count[5] << endl;
    cout << endl
         << "Average salary of Quality Assurance Analyst is : " << totalQA / count[6] << endl;
    int max2 = INT16_MIN;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].salary > max2)
        {
            max2 = employees[i].salary;
        }
    }
    cout << endl
         << endl
         << "Employee with Highest Salary is : " << endl
         << endl;

    for (int i = 0; i < size; i++)
    {
        if (employees[i].salary == max2)
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
}

void analysisScene03(Employee employees[], int size)
{
    int max = INT16_MIN;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].year > max)
        {
            max = employees[i].year;
        }
    }
    cout << endl
         << endl
         << "Employee with longest tenure is : " << endl
         << endl;

    for (int i = 0; i < size; i++)
    {
        if (employees[i].year == max)
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }

    int min = INT16_MAX;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].year < min)
        {
            min = employees[i].year;
        }
    }
    cout << endl
         << endl
         << "Employee with Shortest tenure is : " << endl
         << endl;

    for (int i = 0; i < size; i++)
    {
        if (employees[i].year == min)
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }

    int totalSE = 0, totalDS = 0, totalSSE = 0, totalPM = 0, totalUD = 0, totalQA = 0, totalSDA = 0;
    int count[7] = {};
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Software Engineer")
        {
            totalSE += employees[i].year;
            count[0]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Software Engineer")
        {
            totalSSE += employees[i].year;
            count[1]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Data Scientist")
        {
            totalDS += employees[i].year;
            count[2]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Project Manager")
        {
            totalPM += employees[i].year;
            count[3]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Senior Data Analyst")
        {
            totalSDA += employees[i].year;
            count[4]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " UX Designer")
        {
            totalUD += employees[i].year;
            count[5]++;
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (employees[i].desig == " Quality Assurance Analyst")
        {
            totalQA += employees[i].year;
            count[6]++;
        }
    }

    cout << endl
         << "Average tenure of Software Engineer is : " << totalSE / count[0] << endl;
    cout << endl
         << "Average tenure of Senior Software Engineer is : " << totalSSE / count[1] << endl;
    cout << endl
         << "Average tenure of Data Sceintist is : " << totalDS / count[2] << endl;
    cout << endl
         << "Average tenure of Project Manager is : " << totalPM / count[3] << endl;
    cout << endl
         << "Average tenure of Senior Data Analyst is : " << totalSDA / count[4] << endl;
    cout << endl
         << "Average tenure of UX Designer is : " << totalUD / count[5] << endl;
    cout << endl
         << "Average tenure of Quality Assurance Analyst is : " << totalQA / count[6] << endl;

    int max2 = INT16_MIN;
    for (int i = 0; i < 10; i++)
    {
        if (employees[i].salary > max2)
        {
            max2 = employees[i].salary;
        }
    }
    cout << endl
         << endl
         << "Designation with Highest Salary is : " << endl
         << endl;

    for (int i = 0; i < size; i++)
    {
        if (employees[i].salary == max2)
        {
            cout << "Employee Name: " << employees[i].name << endl;
            cout << "Employee ID: " << employees[i].id << endl;
            cout << "Salary: $" << employees[i].salary << endl;
            cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
            cout << "Designation: " << employees[i].desig << endl;
        }
    }
}

void analysisScene04(Employee employees[], int size)
{
    int countSwap = 0, countComp = 0;
    auto start_time = chrono::high_resolution_clock::now();
    for (int pass = 0; pass < size; pass++)
    {
        for (int i = 0; i < size - pass; i++)
        {
            if (employees[i].salary > employees[i + 1].salary)
            {
                Employee temp = employees[i];
                employees[i] = employees[i + 1];
                employees[i + 1] = temp;
                countSwap++;
            }
            countComp++;
        }
    }
    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time);

    // Displaying
    for (int i = 0; i < size; i++)
    {
        cout << "Employee Name: " << employees[i].name << endl;
        cout << "Employee ID: " << employees[i].id << endl;
        cout << "Salary: $" << employees[i].salary << endl;
        cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
        cout << "Designation: " << employees[i].desig << endl;
        cout << endl;
    }
    cout << endl
         << "Number of Swap performed is : " << countSwap << endl;
    cout << endl
         << "Number of comparisons performed is : " << countComp << endl;

    cout << "Bubble sort take a time of : " << duration.count() << " seconds" << endl;
}

void analysisScene05(Employee employees[], int size)
{
    int countSwap = 0, countComp = 0;
    auto start_time = chrono::high_resolution_clock::now();
    int arr[10];
    for (int i = 0; i < size; i++)
    {
        arr[i] = employees[i].year;
    }
    for (int pass = 0; pass < size; pass++)
    {
        for (int i = 0; i < size - pass; i++)
        {
            if (arr[i] < arr[i + 1])
            {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;

                Employee temp2 = employees[i];
                employees[i] = employees[i + 1];
                employees[i + 1] = temp2;
                countSwap++;
            }
            countComp++;
        }
    }
    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time);

    // Displaying
    for (int i = 0; i < size; i++)
    {
        cout << "Employee Name: " << employees[i].name << endl;
        cout << "Employee ID: " << employees[i].id << endl;
        cout << "Salary: $" << employees[i].salary << endl;
        cout << "Date of Joining: " << employees[i].date[0] << "-" << employees[i].date[1] << "-" << employees[i].date[2] << endl;
        cout << "Designation: " << employees[i].desig << endl;
        cout << endl;
    }
    cout << endl
         << "Number of Swap performed is : " << countSwap << endl;
    cout << endl
         << "Number of comparisons performed is : " << countComp << endl;

    cout << "Bubble sort take a time of : " << duration.count() << " seconds" << endl;
}